const firebaseConfig = {
    apiKey: "AIzaSyDt2DsPS8W08PghNlU2ZBBYGu3-FOOWK4o",
    authDomain: "pomodoro-party-8e414.firebaseapp.com",
    projectId: "pomodoro-party-8e414",
    storageBucket: "pomodoro-party-8e414.appspot.com",
    messagingSenderId: "453359878600",
    appId: "1:453359878600:web:f9a9eb37226975477f40fd",
    measurementId: "G-QSSKPMYF1S"
}